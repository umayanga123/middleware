=============Chirp_Middleware==================================

* In this project , we built our own middleware.we name it 
	as CHIRP Middleware. 


============CONTANT PROJECT====================================

*project compile version contain in the compile_project folder.

*netbeans_project contain all soruce code file and you can open both project using netbeans.

*screenshot folder contain some screen shots.

*chirp_middleware_doc is documantaion file.


===============RUN PROJECT=====================================
*Test and run win7 / 64 bit version.

*first you must run the server.I bind 1665 port as localhost port.



=================RUN SERVER====================================

*To run the project from the command line, go to the 
"\compile_project\server" and
		type the following:

	java -jar "Server.jar" 



================RUN CLIENTS===================================

*In this example we built two client (CLIENT & FIB_CLIENT)

*RUN CLIENT

	To run the project from the command line, go to the dist folder and
	type the following:



	java -jar "Client.jar"
	java -jar "Fib_Client.jar"




================THANK YOU=======================================