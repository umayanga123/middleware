/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.util.Scanner;
import remote_models_stub.Remote_Cal_Stub;
import remote_models_stub.Remote_Cal;

/**
 *
 * @author user
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here


        Scanner input = new Scanner(System.in);
        while (true) {

            System.out.println("\nSELECT CALCULATION TYPE :");
            System.out.println("PRESS A - ADD\nPRESS S - SUBSTRACTION\nPRESS D - DIVITION\nPRESS M - MULTIPLICATION\nPRESS E - EXIT\n");
            String type = input.next();

            if (type == null ? "E" != null : !type.equals("E")) {

                System.out.print("Input NO 1: ");
                double x = input.nextInt();

                System.out.print("Input NO 2: ");
                double y = input.nextInt();

                Remote_Cal a = new Remote_Cal_Stub();


                if (type == null ? "A" == null : type.equals("A")) {
                    //System.out.println("AADD");
                    double add = a.add(x, y, 1);
                    System.out.println("value :" + add);
                } else if (type == null ? "S" == null : type.equals("S")) {
                    //System.out.println("sub");
                    double sub = a.sub(x, y, 2);
                    System.out.println("value :" + sub);
                } else if (type == null ? "D" == null : type.equals("D")) {

                    double div = a.sub(x, y, 3);
                    if (div == -1.00001) {
                        System.out.println("CANNOT DIVIDEDBY ZERO");
                    } else {
                        System.out.println("value :" + div);
                    }

                } else if (type == null ? "M" == null : type.equals("M")) {
                    double mul = a.sub(x, y, 4);
                    System.out.println("value :" + mul);

                } else if (type == null ? "E" == null : type.equals("E")) {
                    System.out.println("THANK YOU...!");
                    System.exit(0);
                } else {
                    System.out.println("PLEASE SELECT VALIED SELECTION");
                }
            } else {
                System.out.println("THANK YOU...!");
                System.exit(0);
            }

        }
    }
}
