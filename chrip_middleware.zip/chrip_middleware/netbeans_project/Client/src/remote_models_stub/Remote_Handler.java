/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remote_models_stub;

import client.Configuration;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import protocol.Bucket;
import protocol.GDTweet;

/**
 *
 * @author csc23
 */
public class Remote_Handler {

    Configuration cfg;
    Socket s;
    ObjectOutputStream out = null;
    ObjectInputStream in = null;

    public Remote_Handler() {
        try {
            cfg = new Configuration();
            cfg.getConfiguration();
            s = new Socket(cfg.serverAddress, cfg.serverSocketNumber);
            out = new ObjectOutputStream(s.getOutputStream());
            in = new ObjectInputStream(s.getInputStream());
        } catch (UnknownHostException ex) {
            Logger.getLogger(Remote_Handler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Remote_Handler.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public boolean sendBucket(Bucket b) {
        try {
            GDTweet rdt;
            do {
                out.writeObject((Object) b);
                out.flush();
                Object or = in.readObject();
                rdt = (GDTweet) or;

            } while (!rdt.getCflag());

        } catch (UnknownHostException ex) {
            System.out.println("UnknownHost Exception");
        } catch (IOException ex) {
            System.out.println("IO error Exception");
        } catch (ClassNotFoundException ex) {
            System.out.println("Class not found");
        }
        return true;
    }

    public boolean sendGDTweet(GDTweet t) {
        return (this.sendObject(t));
    }

    private boolean sendObject(Object o) {
        try {
            out.writeObject(o);
            out.flush();

        } catch (UnknownHostException ex) {
            System.out.println("UnknownHost Exception");
        } catch (IOException ex) {
            System.out.println("IO error Exception");
        }
        return true;
    }

    public Object getBukket() {
        try {
            Object clientMsg = in.readObject();
            //System.out.println(clientMsg);
            return clientMsg;
        } catch (IOException ex) {
            Logger.getLogger(Remote_Handler.class.getName()).log(Level.SEVERE, null, ex);
            return "false";
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Remote_Handler.class.getName()).log(Level.SEVERE, null, ex);
            return "false";
        }
    }

}
