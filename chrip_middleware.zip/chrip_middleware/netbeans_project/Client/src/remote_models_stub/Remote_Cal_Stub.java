/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package remote_models_stub;

import client.Configuration;
import java.util.logging.Level;
import java.util.logging.Logger;
import protocol.Bucket;
import protocol.Encrypt;
import protocol.GDTweet;

/**
 *
 * @author csc23
 */
public class Remote_Cal_Stub extends Thread implements Remote_Cal {

    public static Remote_Handler rh = new Remote_Handler();

    @Override
    public synchronized double add(double x, double y, int z) {

        Bucket b = new Bucket(x, y, z);
        b.setServiceName(Configuration.nameSpace);
        try {
            GDTweet t = new GDTweet(Encrypt.hashFunction(x+""+y+""+z));
            rh.sendGDTweet(t);
            rh.sendBucket(b);
            
            double value = (Double) rh.getBukket();
            return value;
        } catch (Exception ex) {
            Logger.getLogger(Remote_Cal_Stub.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public synchronized void run() {
        //Loops forever but if listener is paused then skips code
    }

    public synchronized double sub(double x, double y, int z) {
        //System.out.println("send");
        Bucket b = new Bucket(x, y, z);
        b.setServiceName("Cal");
        try {
            GDTweet t = new GDTweet(Encrypt.hashFunction(x+""+y+""+z));
            rh.sendGDTweet(t);
            rh.sendBucket(b);
            
            double value = (Double) rh.getBukket();
            return value;
        } catch (Exception ex) {
            Logger.getLogger(Remote_Cal_Stub.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public synchronized double multiple(double x, double y, int z) {
        Bucket b = new Bucket(x, y, z);
        b.setServiceName("Cal");
        try {
            GDTweet t = new GDTweet(Encrypt.hashFunction(x+""+y+""+z));
            rh.sendGDTweet(t);
            rh.sendBucket(b);
            
            double value = (Double) rh.getBukket();
            return value;
        } catch (Exception ex) {
            Logger.getLogger(Remote_Cal_Stub.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public synchronized double divide(double x, double y, int z) {
        Bucket b = new Bucket(x, y, z);
        b.setServiceName("Cal");
        try {
            GDTweet t = new GDTweet(Encrypt.hashFunction(x+""+y+""+z));
            rh.sendGDTweet(t);
            rh.sendBucket(b);
            
            double value = (Double) rh.getBukket();
            return value;
        } catch (Exception ex) {
            Logger.getLogger(Remote_Cal_Stub.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}
