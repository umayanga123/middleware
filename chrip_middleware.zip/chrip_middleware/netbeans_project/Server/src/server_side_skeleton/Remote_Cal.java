/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server_side_skeleton;

/**
 *
 * @author user
 */
public interface Remote_Cal {

    public double add(double x, double y);

    public double sub(double x, double y);

    public double multiple(double x, double y);

    public double divide(double x, double y);
}
