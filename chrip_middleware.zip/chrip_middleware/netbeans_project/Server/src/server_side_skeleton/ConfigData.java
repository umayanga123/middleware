/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server_side_skeleton;

import java.util.ArrayList;

/**
 *
 * @author csc23
 */
public class ConfigData {
    
    public static ArrayList<String> NAMESPACES = new ArrayList<String>();

    public static ArrayList<String> getNAMESPACES() {
        return NAMESPACES;
    }

    public static void setNAMESPACES(ArrayList<String> NAMESPACES) {
        ConfigData.NAMESPACES = NAMESPACES;
    }
    
}
