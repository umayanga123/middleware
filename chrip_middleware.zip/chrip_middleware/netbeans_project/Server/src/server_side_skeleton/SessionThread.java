/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server_side_skeleton;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import protocol.Bucket;
import protocol.Encrypt;
import protocol.GDTweet;
import serverMethod.Configuration;

/**
 *
 * @author csc23
 */
public class SessionThread implements Runnable {

    private int serverPort;
    private int serverLimit;
    private int clientID;
    private int onlineUsers;
    private ServerSocket server;
    private Socket socket;
    protected ObjectInputStream in;
    protected ObjectOutputStream out;
    //Thread on which to run this handler
    protected Thread listener;

    public SessionThread(int cI, Socket socket) {
        this.socket = socket;
        this.clientID = cI;
    }

    @Override
    public void run() {
        // System.out.println("work");
        try {
            //Listen to input stream for messages from this client
            while (true) {
                try {
                    boolean cflab = true;
                    
                    Object gdmessage;
                    GDTweet gdt;
                    Bucket b;
                    
                    String ren;
                    do {
                        gdmessage = in.readObject();
                        gdt = (GDTweet) gdmessage;
                        Object clientMsg = in.readObject();
                        b = (Bucket) clientMsg;
                        ren = Encrypt.hashFunction(b.getX() + "" + b.getY() + "" + b.getType());
                        
                        if(!ren.equals(gdt.getSHA1())){
                            cflab = false;
                        }

                        gdt.setCflag(cflab);
                        out.writeObject(gdt);
                    } while (!cflab);
                    
                    double result = Configuration.SKELETON.backbon(b);
                    out.writeObject(result);
                    out.flush();

                } catch (IOException ioe) {
                    //JOptionPane.showMessageDialog( null, "Any of the usual Input/Output related exceptions.", "Termination Error", JOptionPane.ERROR_MESSAGE );
                    break;
                }
            }
        } catch (Exception ignored) {
        } finally {
            stop();
        }
    }

    private void stop() {
        if (listener != null) {

            try {
                System.out.println("Clent " + clientID + " disconnected.");

                listener.interrupt();
                listener = null;

                out.close();
                socket.close();

            } catch (IOException io_ex) {
            }

        }
    }

    public synchronized void start() {
        try {
            // System.out.println("wada");
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            //Create a new thread and start listening to the client
            listener = new Thread(this);
            listener.start();
        } catch (IOException ex) {
            Logger.getLogger(SessionThread.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
