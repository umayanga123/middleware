/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server_side_skeleton;

import protocol.Bucket;

/**
 *
 * @author janaka
 */
public class Skeleton {

    public double backbon(Bucket b) {
        int cal_type = b.getType();
        if(b.getServiceName().equals("Cal")){
        Remote_Cal_Implement x = new Remote_Cal_Implement();
        switch (cal_type) {
            case 1:
                double add = x.add(b.getX(), b.getY());
                return add;
            case 2:
                double sub = x.sub(b.getX(), b.getY());
                return sub;
            case 3:
                double div = x.divide(b.getX(), b.getY());
                return div;
            case 4:
                double mul = x.multiple(b.getX(), b.getY());
                return mul;
            default:

        }
        }else if(b.getServiceName().equals("Fib")){
            Remote_Fib_Implementat rfi = new Remote_Fib_Implementat();
            return rfi.getFib(b.getX());
        }
        return -1.00002;
    }

}
