/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server_side_skeleton;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author janaka
 */
public class Remote_Fib_Implementat implements Remote_Fib {

    public double getFib(double x) {
        try {
            return fibonacciRecusion((int) x);
        } catch (Exception ex) {
            Logger.getLogger(Remote_Fib_Implementat.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }

    // Java program for Fibonacci number using recursion.
    public static int fibonacciRecusion(int number) throws Exception {
        if (number == 1 || number == 2) {
            return 1;
        }

        return fibonacciRecusion(number - 1) + fibonacciRecusion(number - 2); //tail recursion
    }
}
