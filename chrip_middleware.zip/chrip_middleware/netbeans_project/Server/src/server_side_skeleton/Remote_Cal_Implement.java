/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server_side_skeleton;

/**
 *
 * @author user
 */
public class Remote_Cal_Implement implements Remote_Cal {

    public synchronized double add(double x, double y) {
        double result = x + y;
        return result;
    }

    public synchronized double sub(double x, double y) {
        double result = x - y;
        return result;
    }

    public synchronized double divide(double x, double y) {
        if (y == 0) {
            return -1.00001;
        } else {
            double result = x / y;
            return result;
        }
    }

    public synchronized double multiple(double x, double y) {
        double result = x * y;
        return result;
    }
}
