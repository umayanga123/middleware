/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serverMethod;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;
import server_side_skeleton.ConfigData;
import server_side_skeleton.SessionThread;
import server_side_skeleton.Skeleton;

/**
 *
 * @author user
 */
public class Configuration {

    private int serverPort;
    private int clientId;
    private int serverLimit;
    private String count;
    
    public static Skeleton SKELETON = new Skeleton();

    public Configuration() {
    }

    public Configuration(int serverLimit, int serverPort) {
        this.serverLimit = serverLimit;
        this.serverPort = serverPort;
    }

    //Save new Configuration options to file
    protected synchronized void setConfiguration(int newPort, int newLimit) {
        try {
            FileWriter configFile = new FileWriter("serverConfig.cfg");
            configFile.write(newPort + ";" + newLimit + ";");

            configFile.close();
            serverLimit = newLimit;
        } catch (IOException io_e) {
            JOptionPane.showMessageDialog(null, "Cannot Save Configuration File", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    protected synchronized void getConfiguration() {
        try {
            char[] buffer = new char[15];
            FileReader configFile = new FileReader("serverConfig.cfg");
            configFile.read(buffer);


            String value = String.copyValueOf(buffer);
            String[] temp = value.split(";");
            serverPort = Integer.parseInt(temp[0]);
            serverLimit = Integer.parseInt(temp[1]);
            
            if(temp.length > 2){
                for(int i = 2; i < temp.length;++i){
                    ConfigData.NAMESPACES.add(temp[i]);
                }
            }
            
            configFile.close();
        } catch (FileNotFoundException fnf_e) {
            JOptionPane.showMessageDialog(null, "Configuration File Not Found, Using Defaults", "Configuration File Missing", JOptionPane.ERROR_MESSAGE);

            serverPort = 1665;
            serverLimit = 20;
        } catch (IOException io_e) {
            JOptionPane.showMessageDialog(null, "Error Reading Configuration File, Using Defaults", "Configuration Error", JOptionPane.ERROR_MESSAGE);

            serverPort = 1665;
            serverLimit = 20;
        }
    }

    public void runServer() {

        ServerSocket serverSocket = null;
        getConfiguration();
        try {
            serverSocket = new ServerSocket(serverPort);
        } catch (IOException e) {
            System.out.println("Error when creating the port" + e.toString());
        }

        while (true) {
            try {

                if (clientId <= serverLimit) {
                    System.out.println("Server is Waiting...");
                    Socket socket = serverSocket.accept();
                    clientId++;
                    System.out.println("Client " + clientId + "  is connect");
                    SessionThread sessionThread = new SessionThread(clientId, socket);
                    sessionThread.start();
                }else{
                    System.out.println("clients requset reach to maximum level.so please wait.");
                }

            } catch (IOException e) {
                System.out.println("I/O error: " + e.toString());
            }

        }

    }
}
