/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fib_client;

import java.util.Scanner;
import remote_models_stub.Remote_Fib;
import remote_models_stub.Remote_Fib_Stub;

/**
 *
 * @author user
 */
public class Fib_Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("welcome to fibbachi client");
        System.out.println("press -1 to exit");
        while (true) {
            System.out.println("Input Number :");
            int x = input.nextInt();
            if (x != -1 && x > 0) {
                Remote_Fib a = new Remote_Fib_Stub();
                double fib = a.getFib(x);
               
                if (fib == -1.00002) {
                    System.out.println("Please check your config file, service discovery type. \n");
                } else {
                    System.out.println("Fib : " + fib);
                }

            } else {
                System.exit(0);
            }
        }

    }
}
