/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fib_client;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class Configuration {

    public  String serverAddress;
    public  int serverSocketNumber;
    public static String serviceName;
    //private Socket socket;

    //Save new configuration values to file
    public void setConfiguration(String newServer, int newPort) {
        try {
            FileWriter configFile = new FileWriter("clientConfig1.cfg");
            configFile.write(newServer.trim() + ";" + newPort + ";");
            configFile.close();
        } catch (IOException io_e) {
            JOptionPane.showMessageDialog(null, "Cannot Save Configuration File", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Get configuration options from file and store in variables
    public void getConfiguration() {
        try {
            char[] buffer = new char[255];

            FileReader configFile = new FileReader("clientConfig1.cfg");

            configFile.read(buffer);
            serverAddress = String.copyValueOf(buffer);
            String[] temp = serverAddress.split(";");

            serverAddress = temp[0];
            serverSocketNumber = Integer.parseInt(temp[1]);
            serviceName = temp[2];

        } catch (FileNotFoundException fnf_e) {
            JOptionPane.showMessageDialog(null, "Configuration File Not Found, Using Defaults", "Configuration File Missing", JOptionPane.ERROR_MESSAGE);
            serverSocketNumber = 1665;
            serverAddress = "localhost";
        } catch (IOException io_e) {
            JOptionPane.showMessageDialog(null, "Error Reading Configuration File, Using Defaults", "Configuration Error", JOptionPane.ERROR_MESSAGE);
            serverSocketNumber = 1665;
            serverAddress = "localhost";
        }
    }
}
