/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remote_models_stub;

import fib_client.Configuration;
import java.util.logging.Level;
import java.util.logging.Logger;
import protocol.Bucket;
import protocol.Encrypt;
import protocol.GDTweet;

/**
 *
 * @author janaka
 */
public class Remote_Fib_Stub implements Remote_Fib{
    
    public static Remote_Handler rh = new Remote_Handler();
    
    @Override
    public double getFib(double x) {
        
        Bucket b = new Bucket(x,0.0, 0);
        b.setServiceName(Configuration.serviceName);
        try {
            GDTweet t = new GDTweet(Encrypt.hashFunction(x+""+0.0+""+0));
            rh.sendGDTweet(t);
            rh.sendBucket(b);
            
            double value = (Double) rh.getBukket();
            return value;
        } catch (Exception ex) {
            System.out.println("Error in get double");
        }
        return 0;        
        
    }
    
}
