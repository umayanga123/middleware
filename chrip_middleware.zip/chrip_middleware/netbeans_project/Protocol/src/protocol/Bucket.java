/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package protocol;

import java.io.Serializable;

/**
 *
 * @author csc23
 */
public class Bucket implements Serializable{
    
    private double x;
    private double y;
    private int type;
    private String serviceName;

    public Bucket(String serviceName) {
        this.serviceName = serviceName;
    }

    public Bucket(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Bucket(double x, double y, int type) {
        this.x = x;
        this.y = y;
        this.type = type;
    }



    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Bucket{" + "x=" + x + "y=" + y + "type=" + type + '}';
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    
}
