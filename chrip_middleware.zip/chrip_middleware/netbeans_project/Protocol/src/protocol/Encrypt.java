/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protocol;

/**
 *
 * @author janaka
 */
public class Encrypt {

    //not use
    public static String encrypt(String x) throws Exception {
        java.security.MessageDigest digest = null;
        digest = java.security.MessageDigest.getInstance("SHA-1");
        digest.reset();
        digest.update(x.getBytes("UTF-8"));
        return digest.digest().toString();
    }


    //encript to hash
    public static String hashFunction(String x) {
        int hash = 7;
        for (int i = 0; i < x.length(); i++) {
            hash = hash * 31 + x.charAt(i);
        }
        return hash+"";
    }

}
