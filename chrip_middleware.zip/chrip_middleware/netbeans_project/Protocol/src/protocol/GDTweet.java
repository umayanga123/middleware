/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package protocol;

import java.io.Serializable;

/**
 *
 * @author janaka
 */
public class GDTweet implements Serializable{
    
    private String SHA1;
    private boolean cflag;

    public GDTweet(String SHA1) {
        this.SHA1 = SHA1;
    }
    
    public String getSHA1() {
        return SHA1;
    }

    public void setSHA1(String SHA1) {
        this.SHA1 = SHA1;
    }

    public boolean getCflag() {
        return cflag;
    }

    public void setCflag(boolean cflag) {
        this.cflag = cflag;
    }
    
}
